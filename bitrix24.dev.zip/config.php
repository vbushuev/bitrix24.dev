<?php
define("CORE_PATH","../src/");
define("USE_PROXY",true);
require(CORE_PATH."core.php");
?>