<?php
phpinfo();
 ?>
